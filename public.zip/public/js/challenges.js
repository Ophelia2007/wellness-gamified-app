// ============================================
// CHALLENGES MANAGEMENT FUNCTIONS
// ============================================

const user = getUser();
const token = getToken();

// Load all challenges
async function loadChallenges() {
    const container = document.getElementById('challengesList');
    
    try {
        const response = await fetch(`${API_URL}/challenges`);
        
        if (!response.ok) throw new Error('Failed to load challenges');
        
        const challenges = await response.json();
        displayChallenges(challenges);
    } catch (error) {
        console.error('Error loading challenges:', error);
        container.innerHTML = `
            <p style="text-align: center; color: #f44336;">
                Error loading challenges. Please try again.
            </p>
        `;
    }
}

// Display challenges
function displayChallenges(challenges) {
    const container = document.getElementById('challengesList');
    
    if (challenges.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 40px;">
                <div style="font-size: 60px; margin-bottom: 20px;">🎯</div>
                <h3 style="color: #666;">No challenges available yet!</h3>
                <p style="color: #999;">Be the first to create one!</p>
            </div>
        `;
        return;
    }

    container.innerHTML = '<div class="challenge-list"></div>';
    const list = container.querySelector('.challenge-list');

    challenges.forEach(challenge => {
        const challengeCard = createChallengeCard(challenge);
        list.appendChild(challengeCard);
    });
}

// Create challenge card element
function createChallengeCard(challenge) {
    const card = document.createElement('div');
    card.className = 'challenge-item';
    
    const isCreator = user && challenge.creator_id === user.user_id;
    
    card.innerHTML = `
        <div class="challenge-info">
            <div class="challenge-description">${challenge.description}</div>
            <div class="challenge-points">🌟 ${challenge.points} points</div>
            ${isCreator ? '<span style="font-size: 12px; color: #2196F3;">✓ Created by you</span>' : ''}
        </div>
        <div style="display: flex; flex-direction: column; gap: 10px;">
            <button class="btn btn-success btn-sm" onclick="completeChallenge(${challenge.challenge_id}, '${challenge.description.replace(/'/g, "\\'")}')">
                ✓ Complete
            </button>
            ${isCreator ? `
                <button class="btn btn-danger btn-sm" onclick="deleteChallenge(${challenge.challenge_id})">
                    🗑️ Delete
                </button>
            ` : ''}
        </div>
    `;
    
    return card;
}

// Show create challenge form
function showCreateForm() {
    document.getElementById('createForm').classList.remove('hidden');
}

// Hide create challenge form
function hideCreateForm() {
    document.getElementById('createForm').classList.add('hidden');
    document.getElementById('description').value = '';
    document.getElementById('points').value = '';
}

// Create new challenge
async function createChallenge() {
    const description = document.getElementById('description').value.trim();
    const points = parseInt(document.getElementById('points').value);
    
    if (!description || !points || points < 1) {
        alert('Please provide a valid description and points (minimum 1)');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/challenges`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                description,
                user_id: user.user_id,
                points
            })
        });

        const data = await response.json();

        if (response.ok) {
            alert('✅ Challenge created successfully!');
            hideCreateForm();
            loadChallenges(); // Reload challenges
        } else {
            alert(data.message || 'Failed to create challenge');
        }
    } catch (error) {
        console.error('Error creating challenge:', error);
        alert('An error occurred. Please try again.');
    }
}

// Complete a challenge
async function completeChallenge(challengeId, description) {
    const details = prompt(`You're completing: "${description}"\n\nShare your experience (optional):`);
    
    if (details === null) return; // User clicked cancel
    
    try {
        const response = await fetch(`${API_URL}/completion/${challengeId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                user_id: user.user_id,
                details: details || 'Challenge completed!'
            })
        });

        const data = await response.json();

        if (response.ok) {
            alert(`🎉 Challenge completed! You earned points!\n\nCheck your email for details.`);
            
            // Update user points in localStorage
            const currentUser = getUser();
            // Note: Points will be updated on next page load from backend
            
            // Reload page to show updated challenges
            location.reload();
        } else {
            alert(data.message || 'Failed to complete challenge');
        }
    } catch (error) {
        console.error('Error completing challenge:', error);
        alert('An error occurred. Please try again.');
    }
}

// Delete a challenge
async function deleteChallenge(challengeId) {
    if (!confirm('Are you sure you want to delete this challenge? This cannot be undone!')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/challenges/${challengeId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.status === 204 || response.ok) {
            alert('🗑️ Challenge deleted successfully!');
            loadChallenges(); // Reload challenges
        } else {
            const data = await response.json();
            alert(data.message || 'Failed to delete challenge');
        }
    } catch (error) {
        console.error('Error deleting challenge:', error);
        alert('An error occurred. Please try again.');
    }
}